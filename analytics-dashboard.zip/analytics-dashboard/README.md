
# Analytics Dashboard – Full Stack Starter

**Stack**

* **Backend:** NestJS 10 (TypeScript)
* **Frontend:** Angular 17 + D3.js
* **Design:** Glassmorphism (frosted glass UI)

```bash
# 1. Install deps
cd backend && npm i
cd ../frontend && npm i

# 2. Run backend (port 3000)
npm run start:dev

# 3. Run frontend (port 4200)
ng serve
```

The frontend will fetch `/api/snapshot` for chart + map data.
