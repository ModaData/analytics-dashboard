
import {
  Component, OnInit, ElementRef, ViewChild, AfterViewInit,
} from '@angular/core';
import * as d3 from 'd3';
import { json } from 'd3-fetch';
import * as topojson from 'topojson-client';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit, AfterViewInit {
  @ViewChild('barChart') private barChartEl!: ElementRef<SVGSVGElement>;
  @ViewChild('worldMap') private worldMapEl!: ElementRef<SVGSVGElement>;

  data: any;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get('http://localhost:3000/api/snapshot')
      .subscribe((d) => {
        this.data = d;
        this.drawBar();
        this.drawMap();
      });
  }

  ngAfterViewInit() {}

  private drawBar() {
    const svg = d3.select(this.barChartEl.nativeElement);
    svg.selectAll('*').remove();

    const margin = { top: 20, right: 20, bottom: 30, left: 40 };
    const width = +svg.attr('width') - margin.left - margin.right;
    const height = +svg.attr('height') - margin.top - margin.bottom;

    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    const x = d3.scaleBand()
      .domain(this.data.sales.map((d: any) => d.label))
      .rangeRound([0, width])
      .padding(0.2);

    const y = d3.scaleLinear()
      .domain([0, d3.max(this.data.sales, (d: any) => d.value)!])
      .nice()
      .range([height, 0]);

    g.append('g')
      .attr('class', 'axis axis--x')
      .attr('transform', `translate(0,${height})`)
      .call(d3.axisBottom(x));

    g.append('g')
      .attr('class', 'axis axis--y')
      .call(d3.axisLeft(y).ticks(5));

    g.selectAll('.bar')
      .data(this.data.sales)
      .enter().append('rect')
      .attr('class', 'bar')
      .attr('x', (d: any) => x(d.label)!)
      .attr('y', (d: any) => y(d.value))
      .attr('width', x.bandwidth())
      .attr('height', (d: any) => height - y(d.value));
  }

  private drawMap() {
    const svg = d3.select(this.worldMapEl.nativeElement);
    svg.selectAll('*').remove();

    const width = +svg.attr('width');
    const height = +svg.attr('height');

    const projection = d3.geoNaturalEarth1()
      .scale(width / 6.3)
      .translate([width / 2, height / 2]);

    const path = d3.geoPath().projection(projection);

    Promise.all([
      json('https://unpkg.com/world-atlas@2.0.2/countries-110m.json'),
    ]).then(([world]: any) => {
      const countries = topojson.feature(world, world.objects.countries).features;

      const valueScale = d3.scaleLinear<string>()
        .domain([0, d3.max(Object.values(this.data.worldMetric)) as number])
        .range(['#f0f0f0', '#393939']);

      svg.append('g')
        .selectAll('path')
        .data(countries)
        .enter().append('path')
        .attr('d', path as any)
        .attr('fill', (d: any) => {
          const val = this.data.worldMetric[d.id];
          return val ? valueScale(val) : '#e6e6e6';
        })
        .attr('stroke', 'rgba(0,0,0,0.1)');
    });
  }
}
