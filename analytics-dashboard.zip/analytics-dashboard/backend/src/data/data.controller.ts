
import { Controller, Get } from '@nestjs/common';
import { DataService } from './data.service';

@Controller('api')
export class DataController {
  constructor(private readonly data: DataService) {}

  @Get('snapshot')
  snapshot() {
    return this.data.getSnapshot();
  }
}
