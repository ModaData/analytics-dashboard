
import { Injectable } from '@nestjs/common';

@Injectable()
export class DataService {
  getSnapshot() {
    // Dummy numbers — replace with real analytics later
    return {
      sales: [
        { label: 'Q1', value: 132 },
        { label: 'Q2', value: 201 },
        { label: 'Q3', value: 98 },
        { label: 'Q4', value: 167 },
      ],
      worldMetric: { USA: 75, CHN: 60, IND: 55, BRA: 45, DEU: 50 },
      updatedAt: new Date(),
    };
  }
}
